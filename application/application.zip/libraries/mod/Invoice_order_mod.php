<?php

class Invoice_order_mod extends MY_Mod
{

}