<?php

class Transfer_mod extends MY_Mod
{
}