<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Menu_item_mod extends MY_Mod
{

}