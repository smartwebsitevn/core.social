<?php

class Tran_mod extends MY_Mod
{
}