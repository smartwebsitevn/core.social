<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Translate_mod extends MY_Mod
{
	
}