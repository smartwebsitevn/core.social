<?php

class Payment_mod extends MY_Mod
{
}