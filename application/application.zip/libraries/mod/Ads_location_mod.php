<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ads_location_mod extends MY_Mod {

}