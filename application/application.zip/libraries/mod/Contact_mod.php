<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Contact_mod extends MY_Mod
{


}