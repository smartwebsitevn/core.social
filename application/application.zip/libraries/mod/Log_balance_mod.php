<?php

class Log_balance_mod extends MY_Mod
{

}