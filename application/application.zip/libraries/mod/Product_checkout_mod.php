<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Product_checkout_mod extends MY_Mod
{
}