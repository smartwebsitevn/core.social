<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require_once APPPATH.'libraries/Glink/BS_Library'.EXT;
class GLink_library extends BS_Library
{

}
?>